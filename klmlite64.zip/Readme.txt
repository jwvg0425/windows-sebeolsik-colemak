KEYBOARD LAYOUT MANAGER LITE
----------------------------

GENERAL INFORMATION
-------------------
This program allows you to create and modify Microsoft keyboard layout files.
It works with Windows 95, Windows 95-OSR/2, Windows 98 and Windows ME
Operating systems. Also, it works with Windows NT 4.0, Windows 2000 and
Windows XP operating systems. It works both as a standalone application and
Control Panel Item (Keyboard Layout Manager icon).

HOME PAGE
---------
Visit the following URL for the latest information:
http://www.klm32.com

INSTALLATION
------------
Just run the KLMLITE.EXE file and choose the installation directory.
Installation program will make shortcuts to your Start Menu and add an icon in
your Control Panel.

UNINSTALLATION
--------------
Just run the uninstallation program from Start menu, or go to the
Control Panel->Add/Remove programs, find Keyboard Layout Manager item and
double-click on it.

VERSIONS
--------
ver 2.925
*Works with Windows 7 and Windows 8.

ver 2.92
*Added CharMap button on the Keyboard Editor window which opens the Character Map window.

ver 2.91XP
*Introduced 64-bit versions.
*Keyboard Layout Manager works with Windows Vista.

ver 2.90XP
*Corrected a bug regarding large number of diacritics.
*Corrected a bug regarding key names.

ver 2.89XP
*Added Lock Subset feature. This feature locks current subset so it does not
change when you click on keys.

ver 2.88XP
*Added hardware layout appearance. Now you can set the type of the keyboard
that is similar (or equal) to yours.

ver 2.87XP
*Added five special keys editing (Esc, Return, Tab, Space and Backspace).

ver 2.86.2XP
*Fixed bug regarding Numpad "/" key.

ver 2.86.XP
*Added support for Power and WakeUp keys.

ver 2.85.XP
*Added ShiftLock and LRM/RLM features.

ver 2.84.2.XP
*Corrected a bug regarding XP freezing.
*Corrected a bug regarding Caps Alternate and Caps Lock (AltGr) reset.

ver 2.84.XP
*Corrected a bug regarding blank Enter key when saving layout.

ver 2.83.XP
*Added support for "None Joiner Space" (can be found in Farsi language).

ver 2.82.XP
*Added unofficial Lao support.
*Corrected wrong Uzbek abbreviation.

ver 2.81.XP
*Corrected wrong Georgian LCID.

ver 2.80.XP
*Ligatures have 16 characters maximum now.

ver 2.79.XP
*Added 17 new languages.


TROUBLES
--------
If you have any kind of problem with this program, or you need some additional
information, please send mail to:
techsup@klm32.com
